package InvoiceSystem;

public class Government extends Customer {
	
	public Government(String [] tempArray, Person Contact, Address add){
		super(tempArray, Contact, add);
	}
	
	public double totalCost(double cost){
		return 125 + cost;
	}
}
