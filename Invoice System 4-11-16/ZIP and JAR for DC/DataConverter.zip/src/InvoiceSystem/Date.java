/**
*I Coleman, Sarah Kenny, Nisha Rao
*icoleman@huskers.unl.edu / sarah.kenny@huskers.unl.edu / nisha.bookworm@gmail.com
*2/12/16
*Assignment 2
*/
package InvoiceSystem;
import java.math.*;

public class Date {
    
    private int year;
    private int day;
    private int month;
    
    public Date(int d, int m, int y){
        year = y;
        day = d;
        month = m;
    }
    
    //Getters and setters:
    public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}
	
	//Calculates the time between the beginning date and the end date for the invoices
	public int daysBetween(Date other){
        int daysBetween = 0;
        if(other.getMonth() < this.month){
            daysBetween += other.getYear()*365 - this.year*365 - 365;
            daysBetween += 365 - other.getMonth() * 30 + this.month * 30;
        }
        else{
            daysBetween += other.getYear()*365 - this.year*365;
            daysBetween += other.getMonth()*30 - this.month*30;
        }
        daysBetween += Math.abs(other.getMonth() - this.month);
        return daysBetween;
    }
}