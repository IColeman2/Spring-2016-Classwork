package InvoiceSystem;

public class Corporate extends Customer {
	
	public Corporate(String [] tempArray, Person Contact, Address add){
		super(tempArray, Contact, add);
	}
	
	public double totalCost(Equipment product, double cost){
		return cost * 1.07;
    }
    
    public double totalCost(Consultations product, double cost){
    	return (cost - 150) * 1.0425 + 150;
    }
     
    public double totalCost(Licenses product, double cost){
    	return (cost - product.getFlatServiceFee()) * 1.0425 + product.getFlatServiceFee();
    }

}
