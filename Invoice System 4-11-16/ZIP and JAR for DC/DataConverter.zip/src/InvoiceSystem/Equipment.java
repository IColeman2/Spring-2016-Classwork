/**
*I Coleman, Sarah Kenny, Nisha Rao
*icoleman@huskers.unl.edu / sarah.kenny@huskers.unl.edu / nisha.bookworm@gmail.com
*2/12/16
*Assignment 2
*/

package InvoiceSystem;

public class Equipment extends Products{
    
    private double unitCost;
    
    public Equipment(String [] tempArray){
       super(tempArray[0], tempArray[1], "Equipment");
       unitCost = Double.parseDouble(tempArray[3]);
    }
    
    //Getter and setter
    public double getUnitCost() {
		return unitCost;
	}


	public void setUnitCost(double unitCost) {
		this.unitCost = unitCost;
	}

	//Used to get the total cost of the equipment
	public double getTotalCost(int totalEquipment){
        return unitCost * totalEquipment;
    }
}
