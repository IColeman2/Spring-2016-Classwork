/**
*I Coleman, Sarah Kenny, Nisha Rao
*icoleman@huskers.unl.edu / sarah.kenny@huskers.unl.edu / nisha.bookworm@gmail.com
*2/12/16
*Assignment 2
*/
package InvoiceSystem;

public class Licenses extends Products{
    
    private double annualServiceFee;
    private double flatServiceFee;
    
    public Licenses(String[] tempArray){
        super(tempArray[0], tempArray[1], "Licenses");
        annualServiceFee = Double.parseDouble(tempArray[3]);
        flatServiceFee = Double.parseDouble(tempArray[4]);
    }
    
    //Getters and setters
    public double getAnnualServiceFee() {
		return annualServiceFee;
	}

	public void setAnnualServiceFee(double annualServiceFee) {
		this.annualServiceFee = annualServiceFee;
	}

	public double getFlatServiceFee() {
		return flatServiceFee;
	}

	public void setFlatServiceFee(double flatServiceFee) {
		this.flatServiceFee = flatServiceFee;
	}

	public double getTotalCost (Date beginning, Date ending){
        int days = beginning.daysBetween(ending);
        return days * annualServiceFee + flatServiceFee;
    }
}