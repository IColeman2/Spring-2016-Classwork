/**
*I Coleman, Sarah Kenny, Nisha Rao
*icoleman@huskers.unl.edu / sarah.kenny@huskers.unl.edu / nisha.bookworm@gmail.com
*2/12/16
*Assignment 2
*/
package InvoiceSystem;

public class Consultations extends Products{
    
    private double perHourCost;
    private Person consultant;
    
    public Consultations(String[] tempArray, Person c){
        super(tempArray[0], tempArray[1], "Consultations");
        perHourCost = Double.parseDouble(tempArray[4]);
        consultant = c;
    }
    
    //Getters and setters
    public double getPerHourCost() {
		return perHourCost;
	}


	public void setPerHourCost(double perHourCost) {
		this.perHourCost = perHourCost;
	}


	public Person getConsultant() {
		return consultant;
	}


	public void setConsultant(Person consultant) {
		this.consultant = consultant;
	}


	public double getTotalCost(int totalHours){
        return 150 + totalHours*perHourCost;
    }
    
}
