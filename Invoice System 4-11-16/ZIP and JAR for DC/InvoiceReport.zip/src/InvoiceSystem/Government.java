package InvoiceSystem;

public class Government extends Customer {
	
	public Government(String code, String name, Person Contact, Address add){
		super(code, name, Contact, add, "Government");
	}
}
